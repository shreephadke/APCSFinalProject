import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Scanner;

/**
 *  This is the server aspect of our basic networking.
 *  Creates and receives data through a socket. Data includes player winning 
 *  streaks as well updated scores.
 *
 *  @author  Shree Phadke, Lakshay Maharana, Sunhoo Ahn
 *  @version May 31, 2019
 *  @author  Period: 3
 *  @author  Assignment: Networking APCS Final Project
 *
 *  @author  Sources: None
 */
public class Server
{
    /**
     * This is the server class for the networking portion of this program; it
     * creates the socket which the client can connect to, given they have the
     * same port number (the client also needs to have the server machine's
     * local IP address and both machines must be on the same WiFi network).
     * 
     * @param args
     *            - entry point
     * @throws Exception
     *             - IOException
     */
    public static void main( String[] args ) throws Exception
    {
        /**
         * creates the socket which the client can connect to, given they have
         * the same port number
         */
        ServerSocket sersock = new ServerSocket( 6675 );
        Socket sock = sersock.accept();
        Scanner sc = new Scanner( sock.getInputStream() );
        PrintStream p = new PrintStream( sock.getOutputStream() );
        while ( sock.isConnected() )
        {
            String str = sc.nextLine();
            System.out.println( str );
        }

    }

}